Großes Update: Neues UI und Leistungsverbesserungen
Viele Fehlerbehebungen und höhere Stabilität

