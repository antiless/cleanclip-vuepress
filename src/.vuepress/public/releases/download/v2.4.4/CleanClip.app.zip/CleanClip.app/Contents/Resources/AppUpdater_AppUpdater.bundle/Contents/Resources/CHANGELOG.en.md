Major update: New UI and performance improvements
Many fixes and stability improvements

