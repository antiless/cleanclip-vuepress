Mise à jour majeure : nouvelle interface et meilleures performances
De nombreuses corrections et une meilleure stabilité

